# @alessai/mybrowser-mcp

Persistent Chrome automation for Claude Code and any MCP client.

This package is the server side of MyBrowser. It gives an MCP client access to a real browser with navigation, screenshots, extraction, console and network tooling, uploads, downloads, recording, replay, and multi-session coordination.

Important: installing this npm package is only half of the setup. You also need the MyBrowser Chrome extension.

## Fastest Setup for Claude Code

```bash
claude mcp add mybrowser -- npx -y @alessai/mybrowser-mcp
```

Then install the Chrome extension from:

`https://github.com/alessai/MyBrowser-MCP/releases/latest`

Load the extension once. It defaults to the ordinary local server and opens a first-install guide; no token entry is needed.

The server and the extension must be the same version. With an older extension, a 2.1 server refuses `frame` calls with `EXTENSION_TOO_OLD` before doing anything, and tools the extension does not know (such as `browser_mouse`) fail with a message to update and reload it.

## Changes in 2.1 that affect existing agents

- **Agents no longer act on the user's active tab.** Each agent session works only in tabs it opened (`new_tab`, or `browser_navigate`, which opens one when the session has none) or chose with `select_tab` / `tabId`. A tool called before that fails with `NO_SESSION_TAB` and says how to get a tab. A tab another session is using is refused with the name of that session's project folder.
- **Sessions survive MCP host restarts.** Hosts such as OpenCode restart idle MCP processes; the next process started from the same project folder resumes the session and its tabs for up to 2 hours.
- **Agent access switch.** The extension popup has an Agent access switch. When off, the browser disconnects, debugging is detached from every tab and agents get "not connected"; the default browser is not silently replaced.

## Highlights

1. Browser control: tabs, navigation, clicks, typing, forms, hover, drag and drop, and keyboard input
2. Inspection: screenshots with interactive markers, ARIA snapshots, element search, and structured extraction
3. Debugging: console logs, page eval, storage inspection, network capture, performance metrics, and responsive viewport presets
4. Diagnostics: persistent server logs, redacted diagnostics, support bundles, and extension-side copy diagnostics
5. Workflow tools: uploads, downloads, clipboard support, waits, recording, replay, and saved site knowledge
6. Coordination: shared state, persistent default browser selection, tab ownership, session management, locks, and event handlers

## Install

```bash
npm install -g @alessai/mybrowser-mcp
```

## Start

```bash
mybrowser-mcp
```

On first run, MyBrowser writes its config to:

```text
~/.mybrowser/config.json
```

That file contains the token used by authenticated hub and remote modes. The ordinary loopback extension connection does not ask for it. Later `--host`, `--port`, `--token`, and `--local-url-host` overrides apply only to that run; edit the config to change saved settings.

For browsers on another machine, add this device's browser-reachable Tailscale or network address to the existing config object, for example `"localUrlHost": "devbox.tailnet.ts.net"`. Keep the existing host, port, and token fields unchanged.

MyBrowser advertises that address in URL-opening tool descriptions and replaces `localhost`, `127.0.0.1`, and `::1` before dispatch. The development server must also listen on an interface reachable at that address.

The no-flag command is the default same-device mode. It runs on loopback and stops with its MCP client. `--ensure-hub` is an opt-in authenticated detached hub for clients that must share one browser connection across process restarts. For a managed or remote deployment, run one supervised `mybrowser-mcp --hub` process instead; `--hub` fails clearly if it cannot own the configured listener.

## Chrome Extension Required

After installing the npm package, download the Chrome extension from the GitHub Releases page:

`https://github.com/alessai/MyBrowser-MCP/releases/latest`

Then:

1. Unzip the extension
2. Open `chrome://extensions`
3. Enable **Developer mode**
4. Click **Load unpacked**
5. Select the unzipped folder
6. Follow the guide that opens automatically. Ordinary local use needs no popup settings or auth token

## MCP Config Example

```json
{
  "mcpServers": {
    "mybrowser": {
      "command": "mybrowser-mcp",
      "args": []
    }
  }
}
```

## Diagnostics

Server logs are written to:

```text
~/.mybrowser/logs/mybrowser-mcp.log
~/.mybrowser/logs/mybrowser-mcp-errors.log
```

Useful support tools:

1. `browser_diagnostics` - returns redacted server, browser, session, extension, and recent failure information
2. `browser_support_bundle` - writes a redacted support bundle under `~/.mybrowser/support-bundles/`
3. `browser_get_console_logs` - returns browser page console logs
4. `browser_network` - captures and inspects network requests
5. `browser_set_viewport` / `browser_reset_viewport` - applies or clears iPhone, iPad, and desktop viewport emulation
6. `list_browsers`, `select_browser`, `use_default_browser`, `set_default_browser`, `get_default_browser`, `clear_default_browser` - manage multi-browser routing
7. `new_tab`, `keep_tab`, `browser_cleanup` - open temporary research tabs, preserve selected tabs, and clean up session-owned tabs

## Browser Routing and Temporary Tabs

Normal tool calls use the shared default browser. Use `select_browser` only when the user explicitly requests another browser; the session override expires after 30 minutes of tool inactivity and can be cleared immediately with `use_default_browser`. If a configured default is disconnected, routing fails closed instead of silently switching to another browser. `set_default_browser` updates the shared default and returns only the calling session to it.

`new_tab` creates a session-owned temporary tab by default. Pass `temporary: false` when it should persist, or call `keep_tab` before cleanup. After browser research, call `browser_cleanup` on both success and failure paths. It closes tracked temporary tabs on currently connected browsers, releases the caller's tab claims, and restores default routing. Tabs that cannot be closed remain tracked for later cleanup; if the live session opens another tab first, they wait for the next explicit cleanup or session finalization so a stale retry cannot close newer work. Manual, pre-existing, popup-created, non-temporary, kept, and other-session tabs are never inferred as owned and are not closed.

Finalized sessions are cleaned automatically. If a browser was disconnected during finalization, its extension reports only the bounded session IDs in its local temporary-tab registry during authenticated reconnect; the hub returns only the matching in-memory finalized sessions. Older compatible peers can omit these optional fields. Temporary ownership uses `chrome.storage.session`; exact survival across a full browser restart or extension reload depends on Chrome. An abrupt hub-process death loses in-memory finalization tombstones, and explicit cleanup intentionally leaves no standing intent for a disconnected browser because it could otherwise close newer tabs after reconnect.

## Whole-Page Tools (2.0)

These work without any decision model:

- `browser_outline`: every control on the page, including below the fold and collapsed sections, grouped by section with an id (`o12`), role, label and current state. Pass the id as `ref: "o12"` to click, type, hover and select.
- `browser_assert` with `{type: "setting", target, expect}`: check many settings in one call. The control is found from the agent's words; its state is always read by code.
- `browser_fill_form` with `items: [{target, value}]`: set many controls in one call, with `dryRun` to preview. Each item is verified afterwards and other controls that changed are listed. Buttons and links are never clicked.
- `browser_find` with `query`, `browser_wait_for` with `until`, and `browser_triage` (sort a list of cards, then act on the confirmed ones).

When code cannot tell which control is meant, the item comes back as `needs_choice` with up to five candidate ids, so the agent decides in one turn. Page text that addresses AI agents (prompt injection) is flagged in snapshots, outlines and triage output.

## Optional TypeSafe Jev Decision Layer

A decision model resolves the items code is unsure about, which turns most `needs_choice` results into direct answers. Turn it on with `mybrowser-mcp jev set-key` (prompts for your [TypeSafe](https://docs.typesafe.ai) key), or point it at a decision model you run yourself with `mybrowser-mcp jev use-local http://127.0.0.1:8000/v1/systemone` (any server speaking TypeSafe's System One API, such as Strands Decider). The config lives in `~/.mybrowser/config.json`:

```json
"jev": { "apiKey": "apikey_...", "vision": false, "autopilot": false, "minConfidence": 0.7, "timeoutMs": 3000 }
```

With it on:

- Click, type, hover and select fall back to the decision model when their target is not found (only at or above `minConfidence`, never after an action started, and never for a guessed pay/delete/send target below 0.9).
- Setting checks, fills and `browser_find` queries resolve phrases such as "Threads placements" or "CTA" that code alone cannot.
- `browser_check` and `browser_assert` `page` checks answer yes/no or multiple-choice questions about the page; `browser_wait_for` `until` waits for a described state; `browser_triage` labels the cards.
- `browser_run` (only with `"autopilot": true`, `mybrowser-mcp jev autopilot on`): a bounded autopilot for well-defined tasks. It types only the named values the agent passes, never clicks a pay/send/submit/delete control on its own, and hands back on doubt, loops or no progress.

If the model is unreachable, every tool falls back to its no-model behaviour. Sent to the decision model: page URL path, title, visible text, element roles, labels, section and row text, and on/off states (screenshots only with `vision`). Never sent: the values of input, password and text-area fields, the values given to `browser_run`, cookies, or link query values. Text in rich editors (contenteditable) is part of the visible page text.

## Optional Internal Tool Telemetry

Internal telemetry is an opt-in, local development aid for diagnosing repeated tool calls, retries, loops, no-op actions, and recovery behavior. It is **off by default**. MyBrowser does not enable it from an environment variable or send it over the network.

Enable it explicitly when starting an MCP client process:

```bash
mybrowser-mcp --trace-internal --host 127.0.0.1 --port 9009
```

Optional storage controls:

```bash
mybrowser-mcp \
  --trace-internal \
  --trace-dir ~/.mybrowser/traces \
  --trace-retention-days 14 \
  --trace-max-mb 256 \
  --host 127.0.0.1 \
  --port 9009
```

- Default trace directory: `~/.mybrowser/traces`
- Install pseudonymization key: `~/.mybrowser/trace-key`
- Retention range: 1–90 days; default 14 days
- Storage range: 16–2048 MiB; default 256 MiB
- Directories and files are created with private `0700` and `0600` permissions and fail closed on unsafe symlinks or file identities.
- Each MCP client process writes its own append-only JSONL run. A standalone hub does not write telemetry.

Stored events are deliberately narrow: tool names, safe argument presence/count/length summaries, keyed pseudonyms, correlation IDs, bounded durations and size buckets, stable outcome categories, queue/handler timing, and boolean state-change signals. Analyzer results can classify exact or semantic repeats, unchanged retries, error/timeout retries, oscillation, stale references, no-op actions, and recoveries.

MyBrowser does **not** store prompts, model chain-of-thought, typed or form values, passwords, tokens, cookies, clipboard data, page HTML, screenshots, raw URLs/paths, uploaded file paths, raw results, or free-form extension errors. Model identity is unavailable unless a host supplies it explicitly, and is not inferred. Trace files are not included in normal diagnostics or support bundles.

Inspect traces with local-only commands; these commands do not start the MCP server or connect to a hub:

```bash
mybrowser-mcp trace list --json
mybrowser-mcp trace analyze --json
mybrowser-mcp trace analyze --run <run-id>
mybrowser-mcp trace annotate --run <run-id> --call <call-id> --label mistake --note "short local note"
mybrowser-mcp trace export --run <run-id> --out ./mybrowser-trace-export.jsonl
mybrowser-mcp trace purge --older-than-days 14
```

Annotations store the label and, when safe, only an HMAC pseudonym of the optional note. Exports pass through the same closed runtime schema as persisted events and refuse to overwrite an existing output file. Treat even sanitized exports as private development artifacts.

For development, the reproducible disabled-path overhead check is:

```bash
npx --no-install vite-node benchmarks/disabled-telemetry.ts
```

The benchmark compares the real disabled `TelemetryManager.runToolCall()` path against the same representative operation in the same process and fails above 5% median overhead.

If you already installed the package globally, the equivalent Claude Code command is:

```bash
claude mcp add mybrowser -- mybrowser-mcp
```

## Repository

GitHub: `https://github.com/alessai/MyBrowser-MCP`
